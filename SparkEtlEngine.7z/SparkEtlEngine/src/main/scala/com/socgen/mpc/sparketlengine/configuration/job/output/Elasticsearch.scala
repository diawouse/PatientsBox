package com.socgen.mpc.sparketlengine.configuration.job.output

case class Elasticsearch(nodes: String)
{
  require(Option(nodes).isDefined, "Elasticsearch connection: nodes is mandatory.")
}
