package com.socgen.mpc.sparketlengine.output.writers.file

import com.socgen.mpc.sparketlengine.configuration.job.output.File

class JSONOutputWriter(props: Map[String, String], outputFile: Option[File])
  extends FileOutputWriter(Option(props).getOrElse(Map()) + ("format" -> "json"), outputFile)
