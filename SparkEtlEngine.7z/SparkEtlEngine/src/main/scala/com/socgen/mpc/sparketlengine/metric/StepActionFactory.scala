package com.socgen.mpc.sparketlengine.metric

import java.io.File

import com.socgen.mpc.sparketlengine.configuration.metric.Step
import com.socgen.mpc.sparketlengine.exceptions.MetorikkuException
import com.socgen.mpc.sparketlengine.metric.stepActions.Sql
import com.socgen.mpc.sparketlengine.metric.stepActions.Code
import com.socgen.mpc.sparketlengine.utils.FileUtils

object StepFactory {
  def getStepAction(configuration: Step, metricDir: File, metricName: String,
                    showPreviewLines: Int, cacheOnPreview: Option[Boolean],
                    showQuery: Option[Boolean]): StepAction[_] = {
    configuration.sql match {
      case Some(expression) => Sql(expression, configuration.dataFrameName, showPreviewLines, cacheOnPreview, showQuery)
      case None => {
        configuration.file match {
          case Some(filePath) =>
            Sql(
              FileUtils.getContentFromFileAsString(new File(metricDir, filePath)),
              configuration.dataFrameName, showPreviewLines, cacheOnPreview, showQuery
            )
          case None => {
            configuration.classpath match {
              case Some(cp) => {
                Code(cp, metricName, configuration.dataFrameName, configuration.params)
              }
              case None => throw MetorikkuException("Each step requires an SQL query or a path to a file (SQL/Scala)")
            }
          }
        }
      }
    }
  }
}
