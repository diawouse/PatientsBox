package com.socgen.mpc.sparketlengine.exceptions

case class MetorikkuException(private val message: String = "",
                              private val cause: Throwable = None.orNull)
  extends Exception(message, cause)
