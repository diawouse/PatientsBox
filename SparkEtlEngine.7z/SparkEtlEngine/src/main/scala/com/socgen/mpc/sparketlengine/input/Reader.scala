package com.socgen.mpc.sparketlengine.input
import org.apache.spark.sql.{DataFrame, SparkSession}

trait Reader {
  val name: String
  def read(sparkSession: SparkSession): DataFrame
}

