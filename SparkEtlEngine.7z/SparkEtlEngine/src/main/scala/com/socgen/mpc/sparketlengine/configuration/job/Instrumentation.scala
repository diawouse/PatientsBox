package com.socgen.mpc.sparketlengine.configuration.job

import com.socgen.mpc.sparketlengine.configuration.job.instrumentation.InfluxDBConfig

case class Instrumentation(influxdb: Option[InfluxDBConfig])

