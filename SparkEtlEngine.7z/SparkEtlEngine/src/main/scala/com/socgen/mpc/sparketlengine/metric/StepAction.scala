package com.socgen.mpc.sparketlengine.metric

import org.apache.spark.sql.SparkSession

trait StepAction[A] {
  def dataFrameName: String
  def run(sparkSession: SparkSession): A
}
