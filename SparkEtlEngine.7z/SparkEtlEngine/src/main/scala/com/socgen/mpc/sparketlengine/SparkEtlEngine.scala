package com.socgen.mpc.sparketlengine

import com.socgen.mpc.sparketlengine.configuration.job.ConfigurationParser
import com.socgen.mpc.sparketlengine.metric.MetricSet
import org.apache.log4j.LogManager

object SparkEtlEngine extends App {
  val log = LogManager.getLogger(this.getClass)
  log.info("Starting SparkEtlEngine - Parsing configuration")
  val session = Job(ConfigurationParser.parse(args))
  runMetrics(session)

  def runMetrics(job: Job): Unit = {
    job.config.metrics match {
      case Some(metrics) => metrics.foreach(metricSetPath => {
        val metricSet = new MetricSet(metricSetPath)
        metricSet.run(job)
      })
      case None => log.warn("No metrics were defined, exiting")
    }
  }

}
