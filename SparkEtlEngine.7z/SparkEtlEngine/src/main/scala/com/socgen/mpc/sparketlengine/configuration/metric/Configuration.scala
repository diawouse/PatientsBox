package com.socgen.mpc.sparketlengine.configuration.metric

case class Configuration(steps: List[Step], output: Option[List[Output]])
