package com.socgen.mpc.sparketlengine.instrumentation

import com.socgen.mpc.sparketlengine.configuration.job.Instrumentation
import com.socgen.mpc.sparketlengine.instrumentation.influxdb.InfluxDBInstrumentationFactory
import com.socgen.mpc.sparketlengine.instrumentation.spark.SparkInstrumentationFactory

object InstrumentationProvider {
  def getInstrumentationFactory(appName: Option[String], instrumentation: Option[Instrumentation]): InstrumentationFactory = {
    instrumentation match {
      case Some(inst) => inst.influxdb match {
        case Some(influxDB) => {
          new InfluxDBInstrumentationFactory(appName.get, influxDB)
        }
        case None => new SparkInstrumentationFactory()
      }
      case None => new SparkInstrumentationFactory()
    }
  }
}

trait InstrumentationProvider extends Serializable{
  def count(name: String, value: Long, tags: Map[String, String] = Map(), time: Long = System.currentTimeMillis()): Unit
  def gauge(name: String, value: Long, tags: Map[String, String] = Map(), time: Long = System.currentTimeMillis()): Unit
  def close(): Unit = { }
}

trait InstrumentationFactory extends Serializable{
  def create(): InstrumentationProvider
}
