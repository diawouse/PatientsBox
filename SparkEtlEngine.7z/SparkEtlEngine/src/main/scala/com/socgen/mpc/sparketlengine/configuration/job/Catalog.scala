package com.socgen.mpc.sparketlengine.configuration.job

case class Catalog(database: Option[String])

