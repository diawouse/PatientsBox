package com.socgen.mpc.sparketlengine.configuration.job.input

import com.socgen.mpc.sparketlengine.configuration.job.InputConfig
import com.socgen.mpc.sparketlengine.input.Reader
import com.socgen.mpc.sparketlengine.input.readers.file.FileInput

case class File(path: String,
                options: Option[Map[String, String]],
                schemaPath: Option[String],
                format: Option[String]) extends InputConfig {
  override def getReader(name: String): Reader = FileInput(name, path, options, schemaPath, format)
}
